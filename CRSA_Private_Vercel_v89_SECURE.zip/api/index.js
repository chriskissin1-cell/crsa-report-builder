const fs=require('fs');
const path=require('path');
const crypto=require('crypto');

const COOKIE_NAME='crsa_auth';
const SESSION_VALUE='crsa-authorised-v1';
const MAX_AGE=60*60*24*30;

function configuredPassword(){
  return String(process.env.CRSA_REPORT_PASSWORD||'');
}

function secureEqualText(a,b){
  const aa=crypto.createHash('sha256').update(String(a||'')).digest();
  const bb=crypto.createHash('sha256').update(String(b||'')).digest();
  return crypto.timingSafeEqual(aa,bb);
}

function passwordMatches(password){
  const expected=configuredPassword();
  return !!expected && secureEqualText(password,expected);
}

function expectedSession(){
  const password=configuredPassword();
  if(!password)return '';
  const sessionKey=crypto.createHash('sha256')
    .update(`CRSA_REPORT_SESSION|${password}`)
    .digest();
  return crypto.createHmac('sha256',sessionKey).update(SESSION_VALUE).digest('hex');
}

function parseCookies(header=''){
  const out={};
  header.split(';').forEach(part=>{
    const i=part.indexOf('=');
    if(i<0)return;
    out[part.slice(0,i).trim()]=decodeURIComponent(part.slice(i+1).trim());
  });
  return out;
}

function authorised(req){
  const token=parseCookies(req.headers.cookie||'')[COOKIE_NAME]||'';
  const expected=expectedSession();
  try{
    const a=Buffer.from(token,'hex');
    const b=Buffer.from(expected,'hex');
    return a.length===b.length && crypto.timingSafeEqual(a,b);
  }catch{return false}
}

function loginHtml(error=''){
  const errorHtml=error?`<div class="error">${error}</div>`:'';
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0067a3"><title>CRSA Report Builder — Sign in</title><style>
  *{box-sizing:border-box}html,body{min-height:100%;margin:0}body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:linear-gradient(145deg,#eef8fd,#fff);display:grid;place-items:center;padding:22px;color:#123}
  .card{width:min(420px,100%);background:#fff;border:1px solid rgba(0,103,163,.18);border-radius:18px;padding:28px;box-shadow:0 18px 50px rgba(0,50,80,.12)}
  .logo{display:block;width:150px;max-height:85px;object-fit:contain;margin:0 auto 18px}h1{font-size:23px;text-align:center;margin:0 0 6px;color:#0b4f77}p{text-align:center;color:#607382;font-size:14px;line-height:1.45;margin:0 0 22px}label{display:block;font-weight:700;font-size:13px;margin-bottom:7px}input{width:100%;font-size:17px;padding:14px;border:1px solid #bfd0da;border-radius:10px;outline:none}input:focus{border-color:#0067a3;box-shadow:0 0 0 3px rgba(0,103,163,.12)}button{width:100%;margin-top:14px;border:0;border-radius:10px;padding:14px;background:#0067a3;color:#fff;font-size:16px;font-weight:700}.error{background:#fff1f1;color:#9c1c1c;border:1px solid #efc5c5;padding:10px;border-radius:8px;margin-bottom:14px;font-size:13px}.small{font-size:12px;margin-top:15px;color:#82919b}
  </style></head><body><main class="card"><img class="logo" src="/icons/icon-192.png" alt="CRSA"><h1>CRSA Report Builder</h1><p>Private staff access. Enter the report-builder password to continue.</p>${errorHtml}<form method="post" action="/login"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required autofocus><button type="submit">Sign in</button></form><p class="small">Authorised CRSA personnel only.</p></main></body></html>`;
}

function readPrivate(name){return fs.readFileSync(path.join(process.cwd(),'private',name))}
function send(res,status,type,body,headers={}){res.statusCode=status;res.setHeader('Content-Type',type);Object.entries(headers).forEach(([k,v])=>res.setHeader(k,v));res.end(body)}

module.exports=async function handler(req,res){
  if(!configuredPassword()){
    return send(
      res,
      503,
      'text/html; charset=utf-8',
      '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>CRSA Setup Required</title><body style="font-family:-apple-system;padding:28px"><h2>CRSA Report Builder setup required</h2><p>The Vercel environment variable <strong>CRSA_REPORT_PASSWORD</strong> has not been configured.</p></body>',
      {'Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow, noarchive'}
    );
  }

  const url=new URL(req.url,'https://crsa.invalid');
  const pathname=url.pathname;

  // Non-sensitive PWA support files can be fetched before sign-in.
  if(pathname==='/manifest.webmanifest')return send(res,200,'application/manifest+json; charset=utf-8',readPrivate('manifest.webmanifest'),{'Cache-Control':'public,max-age=3600'});
  if(pathname==='/sw.js')return send(res,200,'application/javascript; charset=utf-8',readPrivate('sw.js'),{'Cache-Control':'no-cache','Service-Worker-Allowed':'/'});
  if(/^\/icons\/icon-(180|192|512)\.png$/.test(pathname)){
    const name=pathname.split('/').pop();
    return send(res,200,'image/png',readPrivate(path.join('icons',name)),{'Cache-Control':'public,max-age=86400'});
  }

  if(pathname==='/login' && req.method==='POST'){
    let password='';
    if(req.body && typeof req.body==='object')password=req.body.password||'';
    else if(typeof req.body==='string')password=new URLSearchParams(req.body).get('password')||'';
    else{
      const chunks=[];
      for await(const chunk of req)chunks.push(chunk);
      password=new URLSearchParams(Buffer.concat(chunks).toString('utf8')).get('password')||'';
    }

    if(passwordMatches(password)){
      res.statusCode=303;
      res.setHeader('Set-Cookie',`${COOKIE_NAME}=${expectedSession()}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${MAX_AGE}`);
      res.setHeader('Location','/');
      return res.end();
    }

    await new Promise(r=>setTimeout(r,850));
    return send(res,401,'text/html; charset=utf-8',loginHtml('Incorrect password. Please try again.'),{'Cache-Control':'no-store'});
  }

  if(pathname==='/logout'){
    res.statusCode=200;
    res.setHeader('Set-Cookie',`${COOKIE_NAME}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`);
    res.setHeader('Cache-Control','no-store');
    res.setHeader('Content-Type','text/html; charset=utf-8');
    return res.end(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>CRSA Locked</title><body style="font-family:-apple-system;padding:28px"><h2>CRSA Report Builder locked</h2><p>Clearing offline access on this device…</p><script>(async()=>{try{for(const r of await navigator.serviceWorker.getRegistrations())await r.unregister();for(const k of await caches.keys())if(k.startsWith('crsa-private-'))await caches.delete(k)}catch{}location.replace('/')})()</script></body>`);
  }

  if(!authorised(req))return send(res,401,'text/html; charset=utf-8',loginHtml(),{'Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow, noarchive'});

  if(pathname==='/' || pathname==='/index.html'){
    return send(res,200,'text/html; charset=utf-8',readPrivate('index.html'),{
      'Cache-Control':'private,no-cache',
      'X-CRSA-Authenticated':'1',
      'X-Robots-Tag':'noindex, nofollow, noarchive',
      'Referrer-Policy':'no-referrer',
      'X-Content-Type-Options':'nosniff',
      'Content-Security-Policy':"frame-ancestors 'none'; base-uri 'self'"
    });
  }

  res.statusCode=302;res.setHeader('Location','/');res.end();
};
