const CACHE_NAME='crsa-private-v88';
const STATIC_ASSETS=[
  '/manifest.webmanifest',
  '/icons/icon-180.png',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];
const PDF_LIBRARY_URLS=[
  'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js',
  'https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js',
  'https://unpkg.com/html2canvas@1.4.1/dist/html2canvas.min.js',
  'https://unpkg.com/jspdf@2.5.1/dist/jspdf.umd.min.js'
];

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE_NAME);
    await cache.addAll(STATIC_ASSETS);
    await Promise.all(PDF_LIBRARY_URLS.map(async url=>{
      try{
        const response=await fetch(new Request(url,{mode:'no-cors',cache:'reload'}));
        await cache.put(url,response);
      }catch{}
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k.startsWith('crsa-private-')&&k!==CACHE_NAME).map(k=>caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET')return;

  if(req.mode==='navigate'){
    event.respondWith((async()=>{
      try{
        const online=await fetch(req);
        // Cache only the authenticated application, never the login screen.
        if(online.ok && online.headers.get('x-crsa-authenticated')==='1'){
          const cache=await caches.open(CACHE_NAME);
          await cache.put('/',online.clone());
        }
        return online;
      }catch{
        const cached=await caches.match('/');
        if(cached)return cached;
        return new Response('<!doctype html><meta name="viewport" content="width=device-width"><title>CRSA Offline</title><body style="font-family:-apple-system;padding:30px"><h2>CRSA Report Builder</h2><p>This device has not yet cached an authorised report-builder session. Connect to the internet and sign in once.</p></body>',{headers:{'content-type':'text/html;charset=utf-8'}});
      }
    })());
    return;
  }

  event.respondWith((async()=>{
    const cached=await caches.match(req);
    if(cached)return cached;
    try{
      const response=await fetch(req);
      if(response && (new URL(req.url).origin===self.location.origin || PDF_LIBRARY_URLS.includes(req.url))){
        const cache=await caches.open(CACHE_NAME);
        try{await cache.put(req,response.clone())}catch{}
      }
      return response;
    }catch(error){throw error}
  })());
});
