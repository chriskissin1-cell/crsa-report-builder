CRSA PRIVATE REPORT BUILDER v88

This package is designed for direct Vercel deployment.

Security:
- Password is verified server-side.
- Plaintext password is NOT stored in the project.
- A salted scrypt password hash is stored server-side.
- Successful login creates a 30-day HttpOnly, Secure, SameSite=Lax session cookie.
- Incorrect passwords are delayed to reduce rapid guessing.
- The report-builder HTML is not served until authentication succeeds.
- Search engine indexing is disabled via X-Robots-Tag.
- Explicit Lock clears the session cookie, service worker, and CRSA offline cache.

iPhone offline use:
1. Sign in online in Safari.
2. Add the authenticated site to Home Screen.
3. Open once while online so the authorised app is cached.
4. Offline use then falls back to the previously authorised cached app.
5. When online, navigation is network-first and the server session is revalidated.

Note: if the existing AI backend only permits the old GitHub Pages origin, its allowed-origin setting must be updated after the Vercel URL is known.


v88 field-workflow changes:
- Added Walk-in robe and Laundry room to room / area selection.
- Materials Inspected now uses Material 1, Material 2, Material 3 and Material 4 dropdowns.
- Additional materials can be added with + Add additional material.
- Each material dropdown uses the existing material list and supports Other with free text.
- Moisture-reading rows are automatically populated from the materials selected for that room.
- Invasive and Non-invasive readings each support + Add additional material for an extra reading material.
- Existing legacy drafts are migrated into the new dropdown structure.


SECURITY UPDATE v89
-------------------
This version removes the password/session secret from the GitHub source.

Required Vercel environment variable:
CRSA_REPORT_PASSWORD

Set it in:
Vercel project -> Settings -> Environment Variables

Use the private CRSA report-builder password as the value.
Apply it to Production, Preview, and Development if those environments are shown.

After adding/changing the environment variable, redeploy the project.

If CRSA_REPORT_PASSWORD is not configured, the site intentionally returns
"CRSA Report Builder setup required" instead of allowing access.
